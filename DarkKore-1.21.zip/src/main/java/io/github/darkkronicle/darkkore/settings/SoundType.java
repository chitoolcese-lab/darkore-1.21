package io.github.darkkronicle.darkkore.settings;

import io.github.darkkronicle.darkkore.config.options.OptionListEntry;
import lombok.Getter;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

import java.util.List;

/**
 * Sound type used for button UI sounds
 */
public enum SoundType implements OptionListEntry<SoundType> {

    /** Normal sounds (just button clicks) */
    NORMAL("normal", null),

    /** Chime sounds */
    CHIME("chime", SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value()),

    /** Bit sounds */
    BIT("bit", SoundEvents.BLOCK_NOTE_BLOCK_BIT.value()),

    /** Vibraphone sounds */
    VIBRAPHONE("vibraphone", SoundEvents.BLOCK_NOTE_BLOCK_IRON_XYLOPHONE.value())
    ;

    private final String key;

    @Getter
    private final SoundEvent sound;

    SoundType(String key, SoundEvent sound) {
        this.key = key;
        this.sound = sound;
    }

    @Override
    public List<SoundType> getAll() {
        return List.of(values());
    }

    @Override
    public SoundType fromString(String string) {
        return OptionListEntry.super.fromString(string);
    }

    @Override
    public String getSaveKey() {
        return key;
    }

    @Override
    public String getDisplayKey() {
        return "darkkore.option.sound." + key;
    }

    @Override
    public String getInfoKey() {
        return "darkkore.option.sound.info." + key;
    }

}
